package db

import (
	"context"
	"fmt"

	"github.com/SeiyaJapon/golang/TwitterGo/models"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var MongoCN *mongo.Client
var Database string

func ConnectDB(ctx context.Context) error {
	connStr := "mongodb+srv://seiyajapon:2008nihon@twittergo.cieajzj.mongodb.net/?retryWrites=true&w=majority"

	var clientOptions = options.Client().ApplyURI(connStr)

	client, err := mongo.Connect(ctx, clientOptions)

	if err != nil {
		fmt.Println(err.Error())

		return err
	}

	fmt.Println("DB Connection Success")

	MongoCN = client
	Database = ctx.Value(models.Key("database")).(string)

	return nil
}

func DBConnected() bool {
	err := MongoCN.Ping(context.TODO(), nil)

	return err == nil
}
