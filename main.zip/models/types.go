package models

type Key string
